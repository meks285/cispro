<?php
$reppstartm = $_GET['reppstartm'];
$reppstartm;
$reppstarty = $_GET['reppstarty'];
$reppstarty;
 
$reppendm = $_GET['reppendm'];
$reppendm;
$reppendy = $_GET['reppendy'];
$reppendy; 
	if($reppstartm=='1' && $reppstarty==2014 ) {$rtime = strtotime('1/1/2014'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='2' && $reppstarty==2014) {$rtime = strtotime('2/1/2014'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='3' && $reppstarty==2014) {$rtime = strtotime('3/1/2014'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='4' && $reppstarty==2014) {$rtime = strtotime('4/1/2014'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='5' && $reppstarty==2014) {$rtime = strtotime('5/1/2014'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='6' && $reppstarty==2014) {$rtime = strtotime('6/1/2014'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='7' && $reppstarty==2014) {$rtime = strtotime('7/1/2014'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='8' && $reppstarty==2014) {$rtime = strtotime('8/1/2014'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='9' && $reppstarty==2014) {$rtime = strtotime('9/1/2014'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='10' && $reppstarty==2014) {$rtime = strtotime('10/1/2014'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='11' && $reppstarty==2014) {$rtime = strtotime('11/1/2014'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='12' && $reppstarty==2014) {$rtime = strtotime('12/1/2014'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='1' && $reppstarty==2015 ) {$rtime = strtotime('1/1/2015'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='2' && $reppstarty==2015) {$rtime = strtotime('2/1/2015'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='3' && $reppstarty==2015) {$rtime = strtotime('3/1/2015'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='4' && $reppstarty==2015) {$rtime = strtotime('4/1/2015'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='5' && $reppstarty==2015) {$rtime = strtotime('5/1/2015'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='6' && $reppstarty==2015) {$rtime = strtotime('6/1/2015'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='7' && $reppstarty==2015) {$rtime = strtotime('7/1/2015'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='8' && $reppstarty==2015) {$rtime = strtotime('8/1/2015'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='9' && $reppstarty==2015) {$rtime = strtotime('9/1/2015'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='10' && $reppstarty==2015) {$rtime = strtotime('10/1/2015'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='11' && $reppstarty==2015) {$rtime = strtotime('11/1/2015'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='12' && $reppstarty==2015) {$rtime = strtotime('12/1/2015'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='1' && $reppstarty==2016) {$rtime = strtotime('1/1/2016'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='2' && $reppstarty==2016) {$rtime = strtotime('2/1/2016'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='3' && $reppstarty==2016) {$rtime = strtotime('3/1/2016'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='4' && $reppstarty==2016) {$rtime = strtotime('4/1/2016'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='5' && $reppstarty==2016) {$rtime = strtotime('5/1/2016'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='6' && $reppstarty==2016) {$rtime = strtotime('6/1/2016'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='7' && $reppstarty==2016) {$rtime = strtotime('7/1/2016'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='8' && $reppstarty==2016) {$rtime = strtotime('8/1/2016'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='9' && $reppstarty==2016) {$rtime = strtotime('9/1/2016'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='10' && $reppstarty==2016) {$rtime = strtotime('10/1/2016'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='11' && $reppstarty==2016) {$rtime = strtotime('11/1/2016'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='12' && $reppstarty==2016) {$rtime = strtotime('12/1/2016'); $rdatestart=date('Y-m-d',$rtime);}
	elseif($reppstartm=='1' && $reppstarty==2017) {$rtime = strtotime('1/1/2017'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='2' && $reppstarty==2017) {$rtime = strtotime('2/1/2017'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='3' && $reppstarty==2017) {$rtime = strtotime('3/1/2017'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='4' && $reppstarty==2017) {$rtime = strtotime('4/1/2017'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='5' && $reppstarty==2017) {$rtime = strtotime('5/1/2017'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='6' && $reppstarty==2017) {$rtime = strtotime('6/1/2017'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='7' && $reppstarty==2017) {$rtime = strtotime('7/1/2017'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='8' && $reppstarty==2017) {$rtime = strtotime('8/1/2017'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='9' && $reppstarty==2017) {$rtime = strtotime('9/1/2017'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='10' && $reppstarty==2017) {$rtime = strtotime('10/1/2017'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='11' && $reppstarty==2017) {$rtime = strtotime('11/1/2017'); $rdatestart=date('Y-m-d',$rtime);} 
	elseif($reppstartm=='12' && $reppstarty==2017) {$rtime = strtotime('12/1/2017'); $rdatestart=date('Y-m-d',$rtime);} 
	else {$rdatestart = "";}
		if($reppendm=='1' && $reppendy==2014 ) {$rtime = strtotime('1/31/2014'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='2' && $reppendy==2014) {$rtime = strtotime('2/28/2014'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='3' && $reppendy==2014) {$rtime = strtotime('3/31/2014'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='4' && $reppendy==2014) {$rtime = strtotime('4/30/2014'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='5' && $reppendy==2014) {$rtime = strtotime('5/31/2014'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='6' && $reppendy==2014) {$rtime = strtotime('6/30/2014'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='7' && $reppendy==2014) {$rtime = strtotime('7/31/2014'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='8' && $reppendy==2014) {$rtime = strtotime('8/31/2014'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='9' && $reppendy==2014) {$rtime = strtotime('9/30/2014'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='10' && $reppendy==2014) {$rtime = strtotime('10/31/2014'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='11' && $reppendy==2014) {$rtime = strtotime('11/30/2014'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='12' && $reppendy==2014) {$rtime = strtotime('12/31/2014'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='1' && $reppendy==2016) {$rtime = strtotime('1/31/2016'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='1' && $reppendy==2015 ) {$rtime = strtotime('1/31/2015'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='2' && $reppendy==2015) {$rtime = strtotime('2/28/2015'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='3' && $reppendy==2015) {$rtime = strtotime('3/31/2015'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='4' && $reppendy==2015) {$rtime = strtotime('4/30/2015'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='5' && $reppendy==2015) {$rtime = strtotime('5/31/2015'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='6' && $reppendy==2015) {$rtime = strtotime('6/30/2015'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='7' && $reppendy==2015) {$rtime = strtotime('7/31/2015'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='8' && $reppendy==2015) {$rtime = strtotime('8/31/2015'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='9' && $reppendy==2015) {$rtime = strtotime('9/30/2015'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='10' && $reppendy==2015) {$rtime = strtotime('10/31/2015'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='11' && $reppendy==2015) {$rtime = strtotime('11/30/2015'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='12' && $reppendy==2015) {$rtime = strtotime('12/31/2015'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='1' && $reppendy==2016) {$rtime = strtotime('1/31/2016'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='2' && $reppendy==2016) {$rtime = strtotime('2/28/2016'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='3' && $reppendy==2016) {$rtime = strtotime('3/31/2016'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='4' && $reppendy==2016) {$rtime = strtotime('4/30/2016'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='5' && $reppendy==2016) {$rtime = strtotime('5/31/2016'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='6' && $reppendy==2016) {$rtime = strtotime('6/30/2016'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='7' && $reppendy==2016) {$rtime = strtotime('7/31/2016'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='8' && $reppendy==2016) {$rtime = strtotime('8/31/2016'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='9' && $reppendy==2016) {$rtime = strtotime('9/30/2016'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='10' && $reppendy==2016) {$rtime = strtotime('10/31/2016'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='11' && $reppendy==2016) {$rtime = strtotime('11/30/2016'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='12' && $reppendy==2016) {$rtime = strtotime('12/31/2016'); $rdateend=date('Y-m-d',$rtime);}
	elseif($reppendm=='1' && $reppendy==2017) {$rtime = strtotime('1/31/2017'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='2' && $reppendy==2017) {$rtime = strtotime('2/28/2017'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='3' && $reppendy==2017) {$rtime = strtotime('3/31/2017'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='4' && $reppendy==2017) {$rtime = strtotime('4/30/2017'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='5' && $reppendy==2017) {$rtime = strtotime('5/31/2017'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='6' && $reppendy==2017) {$rtime = strtotime('6/30/2017'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='7' && $reppendy==2017) {$rtime = strtotime('7/31/2017'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='8' && $reppendy==2017) {$rtime = strtotime('8/31/2017'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='9' && $reppendy==2017) {$rtime = strtotime('9/30/2017'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='10' && $reppendy==2017) {$rtime = strtotime('10/31/2017'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='11' && $reppendy==2017) {$rtime = strtotime('11/30/2017'); $rdateend=date('Y-m-d',$rtime);} 
	elseif($reppendm=='12' && $reppendy==2017) {$rtime = strtotime('12/31/2017'); $rdateend=date('Y-m-d',$rtime);} 
	else {$rdateend = "";}
	
	$date6 = date_create($rdatestart);
date_sub($date6, date_interval_create_from_date_string('6 months'));
$date6low= date_format($date6, 'Y-m-d');


$datecc1 = date_create($rdatestart);
date_sub($datecc1, date_interval_create_from_date_string('12 months'));
$date12low= date_format($datecc1, 'Y-m-d');
?>