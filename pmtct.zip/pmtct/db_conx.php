<?php
$db = new PDO('mysql:host=localhost;dbname=apindb;charset=utf8', 'root', 'Nu66et', array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));

?>